package ac.uk.napier.set07102cw2016;


import java.util.HashMap;
import java.util.Iterator;

import java.util.Map.Entry;

import org.openstreetmap.gui.jmapviewer.Coordinate;

import mapgui.MapGui;
import weather.WeatherData;

/**
 * QUESTION 06
 * 
 * If you decide to answer question 06 then the main method below should be used as the entry point for your application
 * You may use as many other classes as you feel necessary as long as all code is supplied 
 * 
 * Remember to add -Xmx1024m to the VM arguments using menu run --> run configurations in eclipse
 */
public class Answer06 {

	//A HashMap is made called wReadings where the data type of key is Integer and the data type of the value is WeatherStation.
	static HashMap<Integer, WeatherStation> wStations = new HashMap<>();
	public static void main(String[] args) {

		System.out.println("Question 06");

		//Create Weather Stations from data. 
		getWeatherStations();
		//create a method that would find what the WeatherStation WithFewestWeatherReadings
		getWeatherStationWithFewestWeatherReadings();

	}



	public static void getWeatherStations(){
		//A string variable called data which contains data from the WeatherData class
		String[] data = WeatherData.getData();



		//for loop which is used to iterate through the weatheStations and add the weatherReadings to the weatherStations
		for(int i = 1; i < data.length; i++){

			String line = data[i];

			//A string array called elements is made which contains the line variable split into different strings. 
			String[] elements = line.split(",");

			//A string called siteIdis made and needs to be converted to a siteId. 
			String siteIdString = elements[0];

			//A siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);

			if(!wStations.containsKey(siteId)){

				//String variable called siteName is made.
				String siteName = elements[1];

				//Two strings called lat and lon is made.
				//lat and lon both needs to be converted to a double. 
				String latString = elements[2];
				String lonString = elements[3];

				//lat and lon is converted to a double
				double lat = Double.parseDouble(latString);
				double lon = Double.parseDouble(lonString);

				//A new WeatherStation object is made called wS where its parameters are siteId, siteName, lat and lon
				WeatherStation wS = new WeatherStation(siteId, siteName, lat, lon);

				//The object wS is put into the hashMap wStations.
				wStations.put(wS.getSiteId(), wS);


			}





		}

		//Readings from WeatherData file

		for(int i = 1; i < data.length; i++){

			String line = data[i];

			//A string array called elements is made which contains the line variable split into different strings. 
			String[] elements = line.split(",");

			//A string called siteId is made which need to be converted to a integer.
			String siteIdString = elements[0];

			//siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);

			//two strings is made called year and month which later need to be converted to a integer.
			String yearString = elements[4];
			String monthString = elements[5];

			//String called date is made
			String date = elements[6];

			//Two strings called hour and windSpeed is made and later needs to be converted to a integer
			String hourString = elements[7];
			String windSpeedString = elements[8];
			String tempString = elements[9];

			//year, month, hour and windSpeed is converted to a integer. 
			int year = Integer.parseInt(yearString);
			int month = Integer.parseInt(monthString);
			int hour = Integer.parseInt(hourString);
			int windSpeed = Integer.parseInt(windSpeedString);

			//Temp is converted to a double
			double temp = Double.parseDouble(tempString);

			//A new WeatherReading object called wR is made which contains the variables year, month, date, hour, windspeed and temp.
			WeatherReading wR = new WeatherReading(year, month, date, hour, windSpeed, temp);

			//The weather readings is put into a specific weather station
			wStations.get(siteId).getWeatherReadings().add(wR);
		}
	}






	public static void getWeatherStationWithFewestWeatherReadings(){
		// A integer variable called minWeatherReadings and is initialised to the maximum value of what a integer can hold
		int minWeatherReadings = Integer.MAX_VALUE; 

		//A WeatherStation variable called weatherStationWithFewestWeatherReadings is made and it is initialised to null.
		WeatherStation weatherStationWithFewestWeatherReadings = null; 

		//Iterator used for looping through the weather station
		Iterator<Entry<Integer, WeatherStation>> iT = wStations.entrySet().iterator();

		while(iT.hasNext()){
			WeatherStation station = iT.next().getValue();

			//Check if the Weather Readings size of a certain Weather station is less than the minWeatherReadings
			if(station.getWeatherReadings().size() < minWeatherReadings){

				//minWeatherReadings is set to the Weather Readings of the Weather Station size. 
				minWeatherReadings = station.getWeatherReadings().size();

				//WeatherStationWithFewestWeatherReadings is set to the Weather Station
				weatherStationWithFewestWeatherReadings = station;


			}
		}

		//A coordinate object is made called coor and its parameter is the latitude of weatherStationWithFewestWeatherReadings and the longitude of the weatherStationWithFewestWeatherStation
		Coordinate coor = new Coordinate(weatherStationWithFewestWeatherReadings.getLat(), weatherStationWithFewestWeatherReadings.getLon());

		//The weatherStationWithFewestWeatherReadings outputs to the screen
		System.out.println("The Weather Station with the fewest weather readings is " + weatherStationWithFewestWeatherReadings);

		//The latitude and longitude of weatherStationWithFewestWeatherReadings is put into the map and the map is displayed on the screen
		MapGui.showMap(coor);
	}

}
