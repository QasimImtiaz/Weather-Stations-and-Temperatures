package ac.uk.napier.set07102cw2016;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.openstreetmap.gui.jmapviewer.Coordinate;

public class Postcode extends Coordinate {
	
	
	private static String[] postCodes;
	//A string instance variable called pCode is made.
	private String pCode; 
	
	
	

	
	
	


	
	//A public method constructor is made called Postcode is made which parameters are pCode, lat and lon. 
	public Postcode(String pCode, double lat, double lon) {
		super(lat, lon);
		
		this.pCode = pCode;
		

	}
    
	//A getter method called getpCode is made which returns the pCode when the method is called
	public String getpCode() {
		return pCode;
	}

	//A setter method called setpCode is made which set the pCode when the method is called by another method. 
	public void setpCode(String pCode) {
		this.pCode = pCode;
	}
	
	
 
	
	
   

	
	
	public static String [] getEHPostCodes(){
		
		if(postCodes == null){
			ArrayList<String> dataList = new ArrayList<>();
			try {
				BufferedReader reader = new BufferedReader(new FileReader("eh.csv"));
				String line; 								
				while((line = reader.readLine()) != null){
					dataList.add(line);
				}
				postCodes= new String[dataList.size()];
				dataList.toArray(postCodes);	
				reader.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return postCodes;
	}
	
public static String [] getAllPostCodes(){
		
		if(postCodes == null){
			ArrayList<String> dataList = new ArrayList<>();
			try {
				BufferedReader reader = new BufferedReader(new FileReader("postcodes.csv"));
				String line; 								
				while((line = reader.readLine()) != null){
					dataList.add(line);
				}
				postCodes= new String[dataList.size()];
				dataList.toArray(postCodes);	
				reader.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return postCodes;
	}
	
}
