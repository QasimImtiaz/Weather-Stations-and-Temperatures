package ac.uk.napier.set07102cw2016;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import mapgui.MapGui;

import org.openstreetmap.gui.jmapviewer.Coordinate;

import weather.WeatherData;

/**
 * QUESTION 08
 * 
 * If you decide to answer question 08 then the main method below should be used as the entry point for your application
 * You may use as many other classes as you feel necessary as long as all code is supplied 
 * 
 * Remember to add -Xmx1024m to the VM arguments using menu run --> run configurations in eclipse
 */
public class Answer08 {
	//A HashMap is made called wReadings where the data type of key is Integer and the data type of the value is WeatherStation.
	static HashMap<Integer, WeatherStation> wStations = new HashMap<>();
	
	
	public static void main(String[] args) {
		System.out.println("Question 08");
		
		//Create Weather Stations from data. 
		getWeatherStations();
		
		//create a method that would find the  the minimum temperature recorded, the weather station that contains the minimum temperature recorded, maximum temperature recorded, weather station that contains the maximum temperature recorded and also the mean of the minimum and maximum temperature recorded. 
		//The method should output these temperatures and the weather stations that contains these temperatures.
		getMinMaxAndMeanTempOfWeatherStation();
		
	}
	
	
	
	public static void getWeatherStations(){
		//A string variable called data which contains data from the WeatherData class
		String[] data = WeatherData.getData();
		
		
		
		//for loop which is used to iterate through the weatheStations and add the weatherReadings to the weatherStations
		for(int i = 1; i < data.length; i++){
			
			String line = data[i];
			
			//A string array called elements is made which contains the line variable split into different strings. 
			String[] elements = line.split(",");
			
			//A string called siteIdis made and needs to be converted to a siteId. 
			String siteIdString = elements[0];
			
			//A siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);
			
			if(!wStations.containsKey(siteId)){
				
			    //String variable called siteName is made.
				String siteName = elements[1];
				
				//Two strings called lat and lon is made.
				//lat and lon both needs to be converted to a double. 
				String latString = elements[2];
				String lonString = elements[3];
				
				//lat and lon is converted to a double
				double lat = Double.parseDouble(latString);
				double lon = Double.parseDouble(lonString);
				
				//A new WeatherStation object is made called wS where its parameters are siteId, siteName, lat and lon
				WeatherStation wS = new WeatherStation(siteId, siteName, lat, lon);
				
				//The object wS is put into the hashMap wStations.
				wStations.put(wS.getSiteId(), wS);
				
			    
			}
			
			
			
			
			
		}
		
		//Readings from WeatherData file
		
		for(int i = 1; i < data.length; i++){
			
			String line = data[i];
			
			//A string array called elements is made which contains the line variable split into different strings. 
			String[] elements = line.split(",");
			
			//A string called siteId is made which need to be converted to a integer.
			String siteIdString = elements[0];
			
			//siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);
			
			//two strings is made called year and month which later need to be converted to a integer.
			String yearString = elements[4];
			String monthString = elements[5];
			
			//String called date is made
			String date = elements[6];
			
			//Two strings called hour and windSpeed is made and later needs to be converted to a integer
			String hourString = elements[7];
			String windSpeedString = elements[8];
			String tempString = elements[9];
			
			//year, month, hour and windSpeed is converted to a integer. 
			int year = Integer.parseInt(yearString);
			int month = Integer.parseInt(monthString);
			int hour = Integer.parseInt(hourString);
			int windSpeed = Integer.parseInt(windSpeedString);
			
			//Temp is converted to a double
			double temp = Double.parseDouble(tempString);
			
			//A new WeatherReading object called wR is made which contains the variables year, month, date, hour, windspeed and temp.
			WeatherReading wR = new WeatherReading(year, month, date, hour, windSpeed, temp);
			
			//The weather readings is put into a specific weather station
			wStations.get(siteId).getWeatherReadings().add(wR);
			
			
		}
	}
	
	
	public static void getMinMaxAndMeanTempOfWeatherStation(){
		
		//A double variable called latitude is made and it is initialised to 0
		double latitude = 0; 
		
		//A double variable called longitude is made and it is initialised to 0
		double longitude = 0; 
		
		//A double variable called maxTemperature is made and initialised to the minimum value of what a double variable is able to hold
		double maxTemperature = Double.MIN_VALUE; 
		
		//A double variable called minTemperature is made and initialised to the maximum value of what a double variable is able to hold.
		double minTemperature = Double.MAX_VALUE; 
		
		//A double variable called averageTemp is made and it is initialised to 0.
		double averageTemp = 0; 
		
		//A double variable called sum is made and it is initialised to 0
		double sum = 0; 
		
        //A double variable called minTemperature is made and 		
		//Iterator used for looping through the weather station. 
		Iterator<Entry<Integer, WeatherStation>> iT = wStations.entrySet().iterator();
	
		while(iT.hasNext()){
			WeatherStation station = iT.next().getValue();
			
			//A new ArrayList called stationsWr is made where it is initialised to the WeatherReadings of weather station
			ArrayList<WeatherReading> stationsWr = station.getWeatherReadings();
			
			//A ArrayList called tempReadings is made with a double data type
			ArrayList<Double> tempReadings = new ArrayList<>();
			
			//For loop is going through each weather readings of each stations to find the maximum temperature of the weather station named Dunkeswell Aerodrome at 11Am during July 2015
			for(int i = 1; i < stationsWr.size(); i++ ){
				
				/***
				 * Check if the temperature of a certain weather station is bigger than the maxTemperature or not.
				 * Check if the siteId of the weatherStation is 3840 or not.
				 * Check if the hour is 11am or not.
				 * Check if the month is July or not.
				 * Check if the year is 2015 or not.
				 */
				
			    if(stationsWr.get(i).getTemp() > maxTemperature && station.getSiteId() == 3840 && stationsWr.get(i).getHour() == 11 && stationsWr.get(i).getMonth() == 7 && stationsWr.get(i).getYear() == 2015){
			    	//The maxTemperature is set to the temperature of the certain Weather Station
			    	maxTemperature = station.getWeatherReadings().get(i).getTemp();
			    	
			    	
			    }
			}
			for(int i = 1; i < stationsWr.size(); i++ ){
			    if(stationsWr.get(i).getTemp() < minTemperature && station.getSiteId() == 3840 && stationsWr.get(i).getHour() == 11 && stationsWr.get(i).getMonth() == 7 && stationsWr.get(i).getYear() == 2015 ){
			    	minTemperature = station.getWeatherReadings().get(i).getTemp();
			    	
			    }
			}
			
			
		    //for loop used to go through each weather readings of each weather stations 
		    for(int i = 1; i < stationsWr.size(); i++){
		    	
		    	//if statement used to check station siteId is 3840, hour is 11am, month is july and year is 2015
		    	if(station.getSiteId() == 3840 && stationsWr.get(i).getHour() == 11 && stationsWr.get(i).getMonth() == 7 && stationsWr.get(i).getYear() == 2015){
		    		
		    		//sum is incremented by temp value
		    		sum += stationsWr.get(i).getTemp();
		    		
		    		//temp values are added to the tempReadings arrayList
		    		tempReadings.add(stationsWr.get(i).getTemp());
		    		
		    		//averageTemp is set to sum divide tempReadings size
		    		averageTemp = sum/tempReadings.size();
		    		
		    		//latitude is set to the latitude of weather station
		    		latitude = station.getLat();
		    		
		    		//longitude is set to the longitude of weather station
		    		longitude = station.getLon();
		    	}
		    }
		    
		    
			
		}
	    
		//A coordinate variable called coor1 is made where the parameters is latitude and longitude 
		Coordinate coor1 = new Coordinate(latitude, longitude);
		
		//coor1 is put on the map and the map is displayed on the screen
		MapGui.showMap(coor1);
		
		//The maximum temperature, minimum temperature and average temperature is displayed on the console
		System.out.println("The maximum temperature is " + maxTemperature + " The minimum temperature is " + minTemperature + " The average temperature is " + averageTemp); 

	
	
		
		
		
			
		
	    
		
		
		
	}
}
