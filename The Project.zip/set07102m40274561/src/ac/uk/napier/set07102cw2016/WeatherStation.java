package ac.uk.napier.set07102cw2016;
import java.util.ArrayList;




public class WeatherStation {
	
	//A ArrayList called wReadings is made which contains the weather readings of each weather station.
	private ArrayList<WeatherReading> wReadings = new ArrayList<>();
	
	//A integer instance variable called siteId is made. 
	private int siteId;
	
	//A string instance variable called siteName is made. 
    private String siteName; 
    
    //Two double instance variable called lat and lon is made. 
    private double lat; 
    private double lon;
    
    //A public method constructor called WeatherStation is made which parameters contains the siteId, siteName, lat and lon variables.
	public WeatherStation(
			int siteId, String siteName, double lat, double lon) {
		super();
		
		this.siteId = siteId;
		this.siteName = siteName;
		this.lat = lat;
		this.lon = lon;
	}
	
	//A getter method called getWeatherReadings is made which returns the wReadings when called. 
	public ArrayList<WeatherReading> getWeatherReadings(){
		return wReadings;
	}
	
	//A setter method called setWeatherReadings is made which set the wReadngs when called.
	public void setWeatherReadings(ArrayList<WeatherReading> weatherReadings){
		this.wReadings = weatherReadings; 
	}
	
	//A getter method called getSideId is made which returns the siteId when called. 
	public int getSiteId() {
		return siteId;
	}
	
	//A setter method called setSiteId is made which set the siteId when called. 
	public void setSiteId(int siteId) {
		this.siteId = siteId;
	}
	
	//A toString method is made which convert the variables to a string when called. 
	@Override
	public String toString() {
		return "WeatherStation [siteId=" + siteId + ", siteName=" + siteName
				+ ", lat=" + lat + ", lon=" + lon + "]";
	}

	//A getter method called getSiteName is made which returns the siteName when called. 
	public String getSiteName() {
		return siteName;
	}
	
	//A setter method called setSiteName is made which set the siteMame when called. 
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	
	//A setter method called getLat is made which returns the lat when called. 
	public double getLat() {
		return lat;
	}
	
	//A setter method called setLat is made which set the lat when called. 
	public void setLat(double lat) {
		this.lat = lat;
	}
	
	//A getter method called getLon is made which returns the lon when called.
	public double getLon() {
		return lon;
	}
	
	//A setter method called setLon is made which set the lon when called. 
	public void setLon(double lon) {
		this.lon = lon;
	}

}
