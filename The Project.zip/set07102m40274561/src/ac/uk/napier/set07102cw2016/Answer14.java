package ac.uk.napier.set07102cw2016;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.openstreetmap.gui.jmapviewer.Coordinate;

import mapgui.MapGui;
import weather.WeatherData;

/**
 * QUESTION 14
 * 
 * If you decide to answer question 14 then the main method below should be used as the entry point for your application
 * You may use as many other classes as you feel necessary as long as all code is supplied 
 * 
 * Remember to add -Xmx1024m to the VM arguments using menu run --> run configurations in eclipse
 */
public class Answer14 {

	// A HashMap is made called poCodesHashMap where the data type of key is Integer
	// and the data type of the value is Postcode.
	static HashMap<String, Postcode> postCodesHashMap = new HashMap<>();

	

	//A ArrayList called poCodeArrayList is made where the data type if Postcode 
	static ArrayList<Postcode> poCodesArrayList = new ArrayList<>();

	//A ArrayList called lat
	public static void main(String[] args) {
		System.out.println("Question 14");
		/*
		 * Add your code below
		 */


		readPostCodes();
		getMostIsolatedEHPostCode();

	}	




	public static void readPostCodes() {
		// A string variable called data which contains data from the
		// WeatherData class
		String[] data = Postcode.getEHPostCodes();

		//A try catch block is needed to catch any file input errors 
		//*try {

		//We use a Buffered Reader to read the file line by line


		for (int i = 1; i < data.length; i++) {
			String line = data[i];








			//we can use the split method of String to extract the individual fields from the comma delimited line to an array
			String[] elements = line.split(",");

			String pCode = elements[0];




			// Two string variables called lat and lon is made which both
			// later needs to be converted to a double.
			String latString = elements[1];
			String lonString = elements[2];

			// lat and lon is converted to a double
			double lat = Double.parseDouble(latString);
			double lon = Double.parseDouble(lonString);

			// A new postcode object called pstCode is made
			Postcode pstCode = new Postcode(pCode, lat, lon);
			
			

			// The object pstCode is put into the arrayList postCodesArrayList
			poCodesArrayList.add(pstCode);



		}


        System.out.println(poCodesArrayList.size());



	}
	public static void getMostIsolatedEHPostCode(){


		//A double variable called postCodeLat1 is made and it is initialised to 0
		double postCodeLat1 = 0;

		//A double variable called postCodeLon1 is made and it is initialised to 0
		double postCodeLon1 = 0; 

		//A double variable called postCodeLat2 is made and it is initialised to 0
		double postCodeLat2 = 0;

		//A double variable called postCodeLon2 is made and it is initialised to 0
		double postCodeLon2 = 0; 





		//A String variable called mostIsolatedPostCode is made and it is set to a null value. 
		//String mostIsolatedPostCode = null;



		//A double variable called minDisatnce is made and it is initialised to the maximum value that a double variable is able to hold
		//double lowestDistanceBetweenAnyOtherPostcode  = poCodesArrayList.get()

		//A double variable called minDistance is made and it is initialised to the maximum value that a double variable is able to hold. 
		//A coordinate variable called coor1 is made and it is initialised to a null value.
		Coordinate coor = null;
		
		

		//A double variable called distance is made and it is initialised to 0. 
		double distance = 0;
		
		//A double variable called maxDistance is made and it is initialised to the minimum value that a double variable is able to hold 
		double maxDistance = Double.MIN_VALUE;
		
		//A string variable called mostIsolatedPostCode is made and it is initialised to null value
		String mostIsolatedPostCode = null;
		
		
		//A double variable called mostIsolatedLat is made and it is initialised to 0
		double mostIsolatedLat = 0; 
		
		//A double variable called mostIsolatedLon is made and it is initialised to 0
		double mostIsolatedLon = 0; 
		

		







		//A for loop is used to iterate all of the post codes 
		for (Postcode pCodes1 : poCodesArrayList) {

			//postCodeLat1 is set to the latitude of pCodes1
			postCodeLat1 = pCodes1.getLat();

			//postCodeLon1 is set to the longitude of pCodes1
			postCodeLon1 = pCodes1.getLon();
			
			
			
			
		

            
			
			for(Postcode pCodes2 : poCodesArrayList){
				//postCodeLat2 is set to the latitude of pCodes2
				postCodeLat2 = pCodes2.getLat();

				//postCodeLon2 is set to the longitude of pCodes2
				postCodeLon2 = pCodes2.getLon();

				
			
				

				
				//distance is set to the distance between the two points
				distance = WeatherData.getDistanceBetweenPoints(postCodeLat1, postCodeLon1, postCodeLat2, postCodeLon2);
					
				
				

			}
			
			
			//if statement used to check that distance is ggreater than maxDistance
			if(distance <= maxDistance){
				
				//mostIsolatedPostCode is set to pCodes1 postcode
				mostIsolatedPostCode = pCodes1.getpCode();
				
				//mostIsolatedPostCode is set to pCodes1 latitude
			    mostIsolatedLat = pCodes1.getLat();
			    
			    //mostIsolatedLon is set to pCodes1 longitude
			    mostIsolatedLon = pCodes1.getLon();
			    
			    			    
			}
		}
			
	     
		//mostIsolatedLat and mostIsolatedLon is added to the parameters of coordinates
		coor = new Coordinate(mostIsolatedLat, mostIsolatedLon);
		//the most isolated post code displayed on the console
		System.out.println(mostIsolatedPostCode);
		
		//coor is added to the map and the map is displayed on the screen
		MapGui.showMap(coor);
			

			






		
		
		
		

	}
}
