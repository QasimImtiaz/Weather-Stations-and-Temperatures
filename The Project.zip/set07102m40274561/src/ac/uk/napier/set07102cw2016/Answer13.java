package ac.uk.napier.set07102cw2016;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import mapgui.MapGui;

import org.openstreetmap.gui.jmapviewer.Coordinate;
import org.openstreetmap.gui.jmapviewer.interfaces.ICoordinate;

import weather.WeatherData;

/**
 * QUESTION 13
 * 
 * If you decide to answer question 13 then the main method below should be used as the entry point for your application
 * You may use as many other classes as you feel necessary as long as all code is supplied 
 * 
 * Remember to add -Xmx1024m to the VM arguments using menu run --> run configurations in eclipse
 */
public class Answer13 {
	
	

	

	// A HashMap is made called wReadings where the data type of key is Integer
	// and the data type of the value is WeatherStation.
	static HashMap<Integer, WeatherStation> wStations = new HashMap<>();

	static //A list of coordinates that will be displayed on a map
	ArrayList<Coordinate> coordinates = new ArrayList<>();



	public static void main(String[] args) {
		System.out.println("Question 13");
		/*
		 * Add your code below
		 */

		getWeatherStations();
		getDifferenceBetweenMedianOfTwoWeatherStations( );


	}	


	public static void getWeatherStations() {
		// A string variable called data which contains data from the
		// WeatherData class
		String[] data = WeatherData.getData();

		// for loop which is used to iterate through the weatheStations and add
		// the weatherReadings to the weatherStations
		for (int i = 1; i < data.length; i++) {

			String line = data[i];

			// A string array called elements is made which contains the line
			// variable split into different strings.
			String[] elements = line.split(",");

			// A string called siteIdis made and needs to be converted to a
			// siteId.
			String siteIdString = elements[0];

			// A siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);

			if (!wStations.containsKey(siteId)) {

				// String variable called siteName is made.
				String siteName = elements[1];

				// Two strings called lat and lon is made.
				// lat and lon both needs to be converted to a double.
				String latString = elements[2];
				String lonString = elements[3];

				// lat and lon is converted to a double
				double lat = Double.parseDouble(latString);
				double lon = Double.parseDouble(lonString);

				// A new WeatherStation object is made called wS where its
				// parameters are siteId, siteName, lat and lon
				WeatherStation wS = new WeatherStation(siteId, siteName, lat,
						lon);

				// The object wS is put into the hashMap wStations.
				wStations.put(wS.getSiteId(), wS);



			}

			

		}

		// Readings from WeatherData file

		for (int i = 1; i < data.length; i++) {

			String line = data[i];

			// A string array called elements is made which contains the line
			// variable split into different strings.
			String[] elements = line.split(",");

			// A string called siteId is made which need to be converted to a
			// integer.
			String siteIdString = elements[0];

			// siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);

			// Two strings called lat and lon is made.
			// lat and lon both needs to be converted to a double.
			String latString = elements[2];
			String lonString = elements[3];

			// lat and lon is converted to a double
			double lat = Double.parseDouble(latString);
			double lon = Double.parseDouble(lonString);

			// two strings is made called year and month which later need to be
			// converted to a integer.
			String yearString = elements[4];
			String monthString = elements[5];

			// String called date is made
			String date = elements[6];

			// Two strings called hour and windSpeed is made and later needs to
			// be converted to a integer
			String hourString = elements[7];
			String windSpeedString = elements[8];
			String tempString = elements[9];

			// year, month, hour and windSpeed is converted to a integer.
			int year = Integer.parseInt(yearString);
			int month = Integer.parseInt(monthString);
			int hour = Integer.parseInt(hourString);
			int windSpeed = Integer.parseInt(windSpeedString);

			// Temp is converted to a double
			double temp = Double.parseDouble(tempString);

			// A new WeatherReading object called wR is made which contains the
			// variables year, month, date, hour, windspeed and temp.
			WeatherReading wR = new WeatherReading(year, month,date, hour,
					windSpeed, temp);

			// The weather readings is put into a specific weather station
			wStations.get(siteId).getWeatherReadings().add(wR);

			

            



		}

		
		
	}

	public static void getDifferenceBetweenMedianOfTwoWeatherStations(){

		//A new ArrayList called tempReadings1 is made with a double variable. 
		ArrayList<Double> tempReadings1 = new ArrayList<>();

	    //A new ArrayList called tempReadings2 is made with a double variable.
		ArrayList<Double> tempReadings2 = new ArrayList<>();


		//A double variable called median1 is made and it is initialised to 0.
		double median1 = 0;

		//A double variable called median2 is made and it is initialised to 0
		double median2 = 0; 

		//A double variable called differenceBetweenTwoMedians is made and it is initialised to 0
		double differenceBetweenTwoMedians = 0; 

		//A double variable called temp1 is made which is initialised to 0
		double temp1 = 0;

		//A double variable called temp2 is made which is initialised to 0
		double temp2 = 0; 

		//A double variable called lat1 is made which is initialised to 0
		double lat1 = 0;

		//A double variable called lat2 is made which is initialised to 0
		double lat2 = 0;

		//A double variable called lon1 is made which is initialised to 0
		double lon1 = 0;

		//A double variable called lon2 is made which is initialised to 0
		double lon2 = 0; 

		//A coordinate variable called coor1 is made which is initoalised to a null value
		Coordinate coor1 = null;

		//A coordinate variable called coor2 is made which is initialised to a null value.
		Coordinate coor2 = null;


		//for loop used to the iterate the variables in the wStations HashMap
		for(WeatherStation w : wStations.values()){
			
			
			for(WeatherReading eachReading : w.getWeatherReadings()){
				//Check if the Weather Station name is FARNBOROUGH, the weather readings recorded by the weather station is in July and also to check if a certain temperature of a weatherstation is greater than maxYemperature
				if(w.getSiteId() == 3768 && eachReading.getMonth() == 7){



					//temp1 is set to temperature values of a weather station
					temp1 = eachReading.getTemp();

					//temp1 is added to my arrayList tempReadings1
					tempReadings1.add(temp1);

					//lat1 is set to latitude of a weather station
					lat1 = w.getLat();

					//lon1 is set to longitude of a weather station
					lon1 = w.getLon();

					//lat1 and lon1 is added to the parameters of coor1
					coor1 = new Coordinate(lat1, lon1);


					//coor1 is added to the coordinates arrayList
					coordinates.add(coor1);








				}
				//Check if the Weather Station name is FARNBOROUGH, the weather readings recorded by the weather station is in July and also to check if a certain temperature of a weatherstation is less than minYemperature
				if(w.getSiteId() == 3166 && eachReading.getMonth() == 7){

					//temp2 is set to temperature of a weather station
					temp2 = eachReading.getTemp();

					//temp2 is added to my arrayList tempReadings2
					tempReadings2.add(temp2);

					//lat2 is set to latitude of a weather station
					lat2 = w.getLat();

					//lon2 is set to longitude of a weather station
					lon2 = w.getLon();	

					//lat2 and lon2 is added to the parameters of coor2
					coor2 = new Coordinate(lat2, lon2);

					//coor2 is added to the coordinates arrayList
					coordinates.add(coor2);
				}
                
				


			}







		}


		

		

		//tempReadings1 is sorted in ascending order
		Collections.sort(tempReadings1);

		//tempReadings1 is sorted in ascending order
		Collections.sort(tempReadings2);


       
		//A integer variable called mid1 which is set to the size of tempReadings1 divide by 2
		int mid1 = tempReadings1.size()/2;

		//median1 is set to tempReadings1 that retrieve mid1 from list
		median1 = (Double)tempReadings1.get(mid1);

		//if statement used to check that the tempReadings1 size is able to divide by 2 
		if(tempReadings1.size() % 2 == 0){

			//Median1 is calculated 
			median1 = (median1 + (Double)tempReadings1.get(mid1-1)/2);


		}

		//A integer variable called mid2 is made which is set to the tempReadings2 size divide by 2
		int mid2 = tempReadings2.size()/2;

		//median2 is set to tempReadings2 that retrieve mid2 from list
		median2 = (Double)tempReadings2.get(mid2);

		//if statement used to check that the tempReadings2 size is able to divide by2 
		if(tempReadings2.size() % 2 == 0){

			//median2 is calculated
			median2 = (median2 + (Double)tempReadings2.get(mid2-1)/2);
		}
		if(median1 > median2){

			//differenceBetweenTwoMedians is set to median1 minus median2
			differenceBetweenTwoMedians = median1 - median2;
		}


		else{

			//diffferenceBetweenTwoMedians is set to median2 minus median1 
			differenceBetweenTwoMedians = median2 - median1; 
		}


		

		//The differenceBetweenTwoMedians output to console
		System.out.println("The difference between the two medians is " + differenceBetweenTwoMedians);


		//The coordinates is put into the map and the map outputs to the screen
		MapGui.showMap(coordinates);



	}


}



