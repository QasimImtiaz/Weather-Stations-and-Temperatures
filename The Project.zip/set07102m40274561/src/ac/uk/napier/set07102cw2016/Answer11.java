package ac.uk.napier.set07102cw2016;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import org.openstreetmap.gui.jmapviewer.Coordinate;

import mapgui.MapGui;
import weather.WeatherData;

/**
 * QUESTION 11
 * 
 * If you decide to answer question 11 then the main method below should be used
 * as the entry point for your application You may use as many other classes as
 * you feel necessary as long as all code is supplied
 * 
 * Remember to add -Xmx1024m to the VM arguments using menu run --> run
 * configurations in eclipse
 */
public class Answer11 {

	// A HashMap is made called wReadings where the data type of key is Integer
	// and the data type of the value is WeatherStation.
	static HashMap<Integer, WeatherStation> wStations = new HashMap<>();
	
	// ArrayList called coordinates made as more than 1 coordinates needs to
			// be used
    static ArrayList<Coordinate> coordinates = new ArrayList<>();

	// A HashMap is made called poCodes where the data type of key is String and
	// the data type of the value is PostCode.
	static ArrayList<Postcode> poCodes = new ArrayList<>();

	public static void main(String[] args) {

		System.out.println("Question 11");
		
		getWeatherStations();

		// Create post codes from data
		readPostCodes();

		// Create method that count the amount of postcodes in the most northern
		// weather station is the radius of 5km
		getNumOfPostCodesIn5KmRadiusOfMostNortherlyWeatherStation();
		
		//Postcode.getPostCodes();

	}

	public static void getWeatherStations() {
		// A string variable called data which contains data from the
		// WeatherData class
		String[] data = WeatherData.getData();

		// for loop which is used to iterate through the weatheStations and add
		// the weatherReadings to the weatherStations
		for (int i = 1; i < data.length; i++) {

			String line = data[i];

			// A string array called elements is made which contains the line
			// variable split into different strings.
			String[] elements = line.split(",");

			// A string called siteIdis made and needs to be converted to a
			// siteId.
			String siteIdString = elements[0];

			// A siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);

			if (!wStations.containsKey(siteId)) {

				// String variable called siteName is made.
				String siteName = elements[1];

				// Two strings called lat and lon is made.
				// lat and lon both needs to be converted to a double.
				String latString = elements[2];
				String lonString = elements[3];

				// lat and lon is converted to a double
				double lat = Double.parseDouble(latString);
				double lon = Double.parseDouble(lonString);

				// A new WeatherStation object is made called wS where its
				// parameters are siteId, siteName, lat and lon
				WeatherStation wS = new WeatherStation(siteId, siteName, lat,
						lon);

				// The object wS is put into the hashMap wStations.
				wStations.put(wS.getSiteId(), wS);

			}

		}

		// Readings from WeatherData file

		for (int i = 1; i < data.length; i++) {

			String line = data[i];

			// A string array called elements is made which contains the line
			// variable split into different strings.
			String[] elements = line.split(",");

			// A string called siteId is made which need to be converted to a
			// integer.
			String siteIdString = elements[0];

			// siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);
			
			// Two strings called lat and lon is made.
			// lat and lon both needs to be converted to a double.
			String latString = elements[2];
			String lonString = elements[3];

			// lat and lon is converted to a double
			double lat = Double.parseDouble(latString);
			double lon = Double.parseDouble(lonString);
			

			// two strings is made called year and month which later need to be
			// converted to a integer.
			String yearString = elements[4];
			String monthString = elements[5];

			// String called date is made
			String date = elements[6];

			// Two strings called hour and windSpeed is made and later needs to
			// be converted to a integer
			String hourString = elements[7];
			String windSpeedString = elements[8];
			String tempString = elements[9];

			// year, month, hour and windSpeed is converted to a integer.
			int year = Integer.parseInt(yearString);
			int month = Integer.parseInt(monthString);
			int hour = Integer.parseInt(hourString);
			int windSpeed = Integer.parseInt(windSpeedString);

			// Temp is converted to a double
			double temp = Double.parseDouble(tempString);

			// A new WeatherReading object called wR is made which contains the
			// variables year, month, date, hour, windspeed and temp.
			WeatherReading wR = new WeatherReading( year, month, date, hour,
					windSpeed, temp);

			// The weather readings is put into a specific weather station
			wStations.get(siteId).getWeatherReadings().add(wR);
		}
	}

	public static void readPostCodes() {
		// A string variable called data which contains data from the
		// WeatherData class
		String[] data = Postcode.getAllPostCodes();

		//A try catch block is needed to catch any file input errors 
		//*try {

		//We use a Buffered Reader to read the file line by line


		for (int i = 1; i < data.length; i++) {
			String line = data[i];








			//we can use the split method of String to extract the individual fields from the comma delimited line to an array
			String[] elements = line.split(",");

			String pCode = elements[0];


		

			// Two string variables called lat and lon is made which both
			// later needs to be converted to a double.
			String latString = elements[1];
			String lonString = elements[2];

			// lat and lon is converted to a double
			double lat = Double.parseDouble(latString);
			double lon = Double.parseDouble(lonString);

			// A new postcode object called pstCode is made
			Postcode pstCode = new Postcode(pCode, lat, lon);

			// The object pstCode is put into hashMap poCodes
			poCodes.add(pstCode);



		}

		//fields 1 and 2 hold the latitude and longitude which need converted to type double
		//create a new Coordinate and add it to a list of coordinates


	

}

					
					
					

	
		

	

	public static void getNumOfPostCodesIn5KmRadiusOfMostNortherlyWeatherStation() {

		// A double variable called lat1 which is set to the minimum value of
		// what a double variable is able to hold.
		double mostNorthernWeatherStationLat = Double.MIN_VALUE;

		// A double variable called lon1 which initialised to 0 is made.
		double mostNorthernWeatherStationLongitude = 0;

		// A double variable called lat2 which is initialised to 0 is made.
		double postcodeLat = 0;

		// A double variable called lon2 which is initialised to 0 is made.
		double postcodeLon = 0;
		
		

		// A integer variable called count that count the amount of Post Codes
		// in the most northern weather station in a rauis of 5km.
		int count = 0;

		

		// A Coordinate variable called coor1 is made and is set to null.
		Coordinate coor1 = null;

		// A Coordinate variable called coor2 is made and is set to null.
		Coordinate coor2 = null;
		
		//Interator is used for looping through the WeatherStations
		Iterator<WeatherStation> stationIterator = wStations.values().iterator();
		
       
		
		while (stationIterator.hasNext()) {

			// A Postcode variable called station is made which is set to the
			// value of iterator
			WeatherStation wS = stationIterator.next();

			// if statement is used to check that the latitude of a certain
			// weather station is bigger than lat1
			if (wS.getLat() > mostNorthernWeatherStationLat) {

				
				// lat1 is set  to a latitude of a certain weather station.
				mostNorthernWeatherStationLat= wS.getLat();

				// lon1 is set to a longitude of a certain weather station.
				mostNorthernWeatherStationLongitude = wS.getLon();

				// coor1 is set to the latitude of mostNorthernWeatherStation
				// and longitude of mostNoerthWeatherStation
				coor1 = new Coordinate(wS.getLat(), wS.getLon());
				
				

			}

			
		}
		
		

		for (Postcode p : poCodes) {

			postcodeLat = p.getLat();

			postcodeLon = p.getLon();

			coor2 = new Coordinate(postcodeLat, postcodeLon);

			// A double variable called radius is made and is set to the
			// distance between the two coordinates.
			double radius = WeatherData.getDistanceBetweenPoints(
					mostNorthernWeatherStationLat,
					mostNorthernWeatherStationLongitude, postcodeLat,
					postcodeLon);
			
			

			if (radius < 5) {
				count += 1;

			}

		}
		
		
		
		

		// A double variable called radius is made and is initialised to the
		// distance between the coordinates divide by 2.

		// The amount of postcods is output in the console
		System.out.println("The amount of postcodes is " + count);
		

		// coor1 is added to the arrayList coordinates.
		coordinates.add(coor1);

		// coor2 is added to the arrayList coordinates.
		coordinates.add(coor2);

		// The two coordinates is added to the map and the map is output on the
		// screen
		MapGui.showMap(coordinates);
		
		
	}

}
