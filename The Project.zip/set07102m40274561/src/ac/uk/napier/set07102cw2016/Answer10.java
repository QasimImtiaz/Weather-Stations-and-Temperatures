package ac.uk.napier.set07102cw2016;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import java.util.Map.Entry;

import org.openstreetmap.gui.jmapviewer.Coordinate;

import mapgui.MapGui;

import weather.WeatherData;

/**
 * QUESTION 10
 * 
 * If you decide to answer question 10 then the main method below should be used as the entry point for your application
 * You may use as many other classes as you feel necessary as long as all code is supplied 
 * 
 * Remember to add -Xmx1024m to the VM arguments using menu run --> run configurations in eclipse
 */
public class Answer10 {
	//A HashMap is made called wReadings where the data type of key is Integer and the data type of the value is WeatherStation.
	static HashMap<Integer, WeatherStation> wStations = new HashMap<>();
	public static void main(String[] args) {

		System.out.println("Question 10");

		//Create Weather Stations from data. 
		getWeatherStations();

		//create a method that would find what is the most southern Weather Station
		mostSouthernWeatherStation();

	}



	public static void getWeatherStations(){
		//A string variable called data which contains data from the WeatherData class
		String[] data = WeatherData.getData();



		//for loop which is used to iterate through the weatheStations and add the weatherReadings to the weatherStations
		for(int i = 1; i < data.length; i++){

			String line = data[i];

			//A string array called elements is made which contains the line variable split into different strings. 
			String[] elements = line.split(",");

			//A string called siteIdis made and needs to be converted to a siteId. 
			String siteIdString = elements[0];

			//A siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);

			if(!wStations.containsKey(siteId)){

				//String variable called siteName is made.
				String siteName = elements[1];

				//Two strings called lat and lon is made.
				//lat and lon both needs to be converted to a double. 
				String latString = elements[2];
				String lonString = elements[3];

				//lat and lon is converted to a double
				double lat = Double.parseDouble(latString);
				double lon = Double.parseDouble(lonString);

				//A new WeatherStation object is made called wS where its parameters are siteId, siteName, lat and lon
				WeatherStation wS = new WeatherStation(siteId, siteName, lat, lon);

				//The object wS is put into the hashMap wStations.
				wStations.put(wS.getSiteId(), wS);


			}





		}

		//Readings from WeatherData file

		for(int i = 1; i < data.length; i++){

			String line = data[i];

			//A string array called elements is made which contains the line variable split into different strings. 
			String[] elements = line.split(",");

			//A string called siteId is made which need to be converted to a integer.
			String siteIdString = elements[0];

			//siteId is converted to a integer.
			int siteId = Integer.parseInt(siteIdString);

			//two strings is made called year and month which later need to be converted to a integer.
			String yearString = elements[4];
			String monthString = elements[5];

			//String called date is made
			String date = elements[6];

			//Two strings called hour and windSpeed is made and later needs to be converted to a integer
			String hourString = elements[7];
			String windSpeedString = elements[8];
			String tempString = elements[9];

			//year, month, hour and windSpeed is converted to a integer. 
			int year = Integer.parseInt(yearString);
			int month = Integer.parseInt(monthString);
			int hour = Integer.parseInt(hourString);
			int windSpeed = Integer.parseInt(windSpeedString);

			//Temp is converted to a double
			double temp = Double.parseDouble(tempString);

			//A new WeatherReading object called wR is made which contains the variables year, month, date, hour, windspeed and temp.
			WeatherReading wR = new WeatherReading(year, month, date, hour, windSpeed, temp);

			//The weather readings is put into a specific weather station
			wStations.get(siteId).getWeatherReadings().add(wR);
		}
	}



	public static void mostSouthernWeatherStation(){

		//A double variable called minLat is made and it is initialised to the maximum value of what a double variable is able hold 
		double minLat = Double.MAX_VALUE;

		//A double variable called monLon is made and it is initialised to 0 
		double minLon = 0; 

		//A WeatherStation variable called mostSouthernWeatherStation is made and it is initialised to a null value 
		WeatherStation mostSouthernWeatherStation = null;

		//A coordinate variable is made and it is initialised to a null value 
		Coordinate coor = null;

		//Iterator used for looping through the weather station
		Iterator<Entry<Integer, WeatherStation>> iT = wStations.entrySet().iterator();
		while(iT.hasNext()){

			WeatherStation station = iT.next().getValue();

			//A ArrayList called stationWr is made which is initialised to the weather readings of weather stations 
			ArrayList<WeatherReading> stationWr = station.getWeatherReadings();

			//A for statement is used to iterate through all of the station weather readings
			for(int i = 1; i < stationWr.size(); i++){

				//if statement used to check that latitude of weather station is less than min latitude 
				if( station.getLat() < minLat){

					//minLat is set to latitude of a weather station 
					minLat = station.getLat();

					//minLon is set to the longitude of a weather station 
					minLon = station.getLon();

					//mostSouthernWeatherStation is set to the weather station 
					mostSouthernWeatherStation = station;

					//minLat and minLon is added to the parameters of coor. 
					coor = new Coordinate(minLat, minLon);


				}
			}
		}

		//The most southern weather station is displayed in the console 
		System.out.println("The most Southern Weather station is " + mostSouthernWeatherStation);

		//coor is put into the map and the map displays on the screen
		MapGui.showMap(coor);



	}
}
