package ac.uk.napier.set07102cw2016;

public class WeatherReading {
	
	//Instance variables called year, month, date, hour, windSpeed and temp is made
    private int year;
    private int month; 
    private String date;
    private int hour; 
    private int windSpeed;
    private double temp;
    
    //public constructor called WeatherReading is made where the year, month, date, hour, windSpeed and temp are the parameters. 
	public WeatherReading(int year, int month, String date, int hour,
			int windSpeed, double temp) {
		super();
		this.year = year;
		this.month = month;
		this.date = date;
		this.hour = hour;
		this.windSpeed = windSpeed;
		this.temp = temp;
	}
	
	//A getter method called getYear is made
	public int getYear() {
		return year;
	}
	
	//A setter method called setYear is made
	public void setYear(int year) {
		this.year = year;
	}
	
	//A getter method called getMonth is made 
	public int getMonth() {
		return month;
	}
	
	//A setter method called setMonth is made
	public void setMonth(int month) {
		this.month = month;
	}
	
	//A getter method called getDate is made
	public String getDate() {
		return date;
	}
	
	//A setter method called setDate is made
	public void setDate(String date) {
		this.date = date;
	}
	
	//A getter method called getHour is made
	public int getHour() {
		return hour;
	}
	
	//A setter method called setHour is made
	public void setHour(int hour) {
		this.hour = hour;
	}
	
	//A getter method called getWindSpeed is made 
	public int getWindSpeed() {
        return windSpeed;
	}
	
	//A setter method called setWindSpeed is made 
	public void setWindSpeed(int windSpeed) {
		this.windSpeed = windSpeed;
	}
	
	//A getter method called getTemp is made 
	public double getTemp() {
		return temp;
	}
	
	//A setter method called setTemp is made 
	public void setTemp(double temp) {
		this.temp = temp;
	} 
    
}
