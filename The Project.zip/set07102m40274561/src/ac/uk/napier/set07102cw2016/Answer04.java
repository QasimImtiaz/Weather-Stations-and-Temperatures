package ac.uk.napier.set07102cw2016;

import weather.WeatherData;

/**
 * QUESTION 04
 * 
 * If you decide to answer question 04 then the main method below should be used as the entry point for your application
 * You may use as many other classes as you feel necessary as long as all code is supplied 
 * 
 * Remember to add -Xmx1024m to the VM arguments using menu run --> run configurations in eclipse
 */
public class Answer04 {
	public static void main(String[] args) {
		System.out.println("Question 04");
		/*
		 * Add your code below
		 */
		
		
	}	
}
